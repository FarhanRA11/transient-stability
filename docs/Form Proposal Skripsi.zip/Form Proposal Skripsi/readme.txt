Semua Form dicetak menggunakan kertas ukuran Kwarto (A4).
Jika dicetak selain menggunakan kertas ukuran Kwarto, maka dokumen tidak akan diproses.

Kartu bimbingan proposal skripsi didaftarkan ke Departemen setelah periode pengajuan proposal skripsi disetujui dan sebelum 
mendaftarkan permohonan skripsi. 
Dikumpulkan pada saat mendaftar ujian pendadaran, telah bimbingan masing2 4x dan sudah ada nilainya.

KRS proposal skripsi diambil hanya sekali.
