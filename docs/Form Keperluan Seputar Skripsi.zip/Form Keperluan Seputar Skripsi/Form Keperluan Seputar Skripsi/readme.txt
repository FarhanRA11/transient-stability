Semua Form dicetak menggunakan kertas ukuran Kwarto (A4).
Jika dicetak selain menggunakan kertas ukuran Kwarto, maka dokumen tidak akan diproses.
Selama skripsi berlangsung (hingga masa pendadaran), KRS skripsi dan pendadaran wajib diambil setiap semester.

Pembimbing I maksimal membimbing 10 mahasiswa.
Mahasiswa tidak perlu mencari Pembimbing II, Pembimbing II akan ditentukan oleh departemen.
Surat permohonan, pernyataan, dan kartu bimbingan skripsi wajib didaftarkan ke departemen minimal 2 (dua) bulan sebelum batas akhir 
setiap periode pendaftaran pendadaran dan telah bimbingan skripsi minimal 10 (sepuluh) kali bimbingan untuk masing-masing dosen pembimbing.

ACC Bagian Keuangan DTETI dilakukan oleh petugas Akademik.
F.1 - S.5 Permohonan Izin Pengambilan Data Skripsi digunakan jika memang diperlukan.
F.1 - S.5 Permohonan Data Skripsi diserahkan ke Front Office lt. 1 DTETI kemudian diproses Akademik dan diambil di Front Office.
F.1 - S.6 Permohonan Izin Penelitian digunakan jika memang diperlukan.
F.1 - S.6 Permohonan Izin Penelitian diserahkan ke Front Office lt. 1 DTETI kemudian diproses Akademik dan diambil di Front Office.


